# StashGraphs StashApp Plugin

This repository contains the **StashGraphs** plugin for the organizer [Stash](https://stashapp.cc/). It provides generic charting functions for other plugins to use.

This plugin utilizes [Chart.js](https://www.chartjs.org) for rendering charts.
