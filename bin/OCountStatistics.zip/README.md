# O-Count Statistics StashApp Plugin

This repository contains the **O-Count Statistics** plugin for the organizer [Stash](https://stashapp.cc/). It Provides locally computed, statistical insights and visualizations instance under `<stash-url>/stats`.


This plugin utilizes [Chart.js](https://www.chartjs.org) for rendering charts.
